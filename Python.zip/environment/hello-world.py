print('Hello, World')
